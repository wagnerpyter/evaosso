# Quick Start - EVA OSSO

## 1. Clonar e Instalar

```bash
git clone https://github.com/wagnerpyter/eva-osso.git
cd eva-osso
npm install
```

## 2. Desenvolvimento Local

```bash
npm run dev
```

Abra http://localhost:3000

## 3. Build para Produção

```bash
npm run build
npm run preview
```

## 4. Deploy no Cloudflare Pages

### Opção A: GitHub Actions (Automático)

1. Fazer push para `main`
2. GitHub Actions fará deploy automaticamente

### Opção B: Manual com Wrangler

```bash
npm install -g @cloudflare/wrangler
wrangler login
npm run deploy
```

## 5. Verificar Site

Acesse https://wagnerpyter.ia.br

## Estrutura do Projeto

```
eva-osso/
├── public/           # Arquivos estáticos
│   ├── index.html    # Portal principal
│   └── book-viewer.html  # Livro mutável
├── src/
│   ├── js/          # Módulos JavaScript
│   ├── css/         # Estilos
│   ├── data/        # Dados dos capítulos
│   └── templates/   # Templates Tracery
├── docs/            # Documentação
└── .github/workflows/  # GitHub Actions
```

## Próximos Passos

1. Ler [DEPLOYMENT.md](./docs/DEPLOYMENT.md) para configuração completa
2. Ler [EVA_OSSO_HYBRID_SKELETON.md](./docs/EVA_OSSO_HYBRID_SKELETON.md) para entender a arquitetura
3. Customizar conteúdo em `src/data/fenomeno-phi-content.json`

## Troubleshooting

**Build falha?**
```bash
rm -rf node_modules package-lock.json
npm install
```

**Site não carrega?**
- Verificar logs no Cloudflare Dashboard
- Verificar se build output directory é `dist`

**Domínio não funciona?**
- Verificar DNS no Cloudflare
- Aguardar propagação DNS (até 48 horas)

---

Para mais informações, veja [README.md](./README.md)
