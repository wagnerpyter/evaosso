# EVA OSSO Framework v1.0 - Livro Mutável Pós-Internet

Um framework experimental para criar **livros mutáveis** que existem em espaço pós-internet, onde a narrativa é gerada proceduralmente, o conteúdo vaza entre capítulos, e o leitor pode navegar infinitamente através de páginas que não existem fisicamente no servidor.

## 🌀 O que é EVA OSSO?

**EVA OSSO** é a sigla para:
- **E**structura (Estrutura)
- **V**ertente (Fluxo)
- **A**daptativa (Adaptativa)
- **O**rganismo (Organismo)
- **S**istema (Sistema)
- **S**imbiótico (Simbiótico)
- **O**scilante (Oscilante)

O framework implementa um **Livro Mutável** baseado no conceito de "Fenômeno Φ" - Os 7 Níveis do Sistema de Empatia Algorítmica. Cada leitura é única, cada página pode ser infinita, e o conteúdo está sempre em transformação.

## ✨ Características Principais

*   **Mutação Narrativa:** O texto se transforma a cada leitura baseado em ritmo, estado e interação
*   **Vazamento Narrativo:** Fragmentos de um capítulo "vazam" para outro, criando uma rede interconectada
*   **Navegação Horizontal:** Em vez de scroll vertical, navegação cinematográfica lado a lado
*   **Páginas Virtuais Infinitas:** Páginas geradas sob demanda (ex: -1, 7, 147) que não existem no servidor
*   **Persistência Local:** Cada página gerada é salva, permitindo que o livro "lembre" de suas mutações
*   **Estética Pós-Internet:** Interface que é arte em si mesma, refletindo net.art e glitch aesthetics

## 🏗️ Arquitetura

O projeto segue uma **arquitetura de 5 camadas**:

```
┌─────────────────────────────────────────────────────────────┐
│                    CAMADA DE APRESENTAÇÃO                   │
│  (Canvas 2D + SVG + Kinetic Typography + Interatividade)   │
├─────────────────────────────────────────────────────────────┤
│                    CAMADA DE NAVEGAÇÃO                      │
│  (Horizontal Scroll + Page Router + Virtual Page Generator) │
├─────────────────────────────────────────────────────────────┤
│                    CAMADA DE NARRATIVA                      │
│  (Book Engine + Narrative Mutation + Tracery Templates)     │
├─────────────────────────────────────────────────────────────┤
│                    CAMADA DE RITMO & VAZAMENTO              │
│  (Rhythm Engine + Leak Network + Seed System)               │
├─────────────────────────────────────────────────────────────┤
│                    CAMADA DE PERSISTÊNCIA                   │
│  (localStorage + IndexedDB + State Management)              │
└─────────────────────────────────────────────────────────────┘
```

## 📁 Estrutura do Projeto

```
eva-osso-github/
├── src/
│   ├── js/
│   │   ├── eva.js                    # Orquestrador central
│   │   ├── rhythm.js                 # Motor de ritmo
│   │   ├── leak.js                   # Sistema de vazamento
│   │   ├── seeds.js                  # Sistema de sementes
│   │   ├── narrative-mutation.js     # Motor de mutação narrativa
│   │   ├── book-engine.js            # Motor do livro mutável
│   │   ├── page-generator.js         # Gerador de páginas virtuais
│   │   ├── page-router.js            # Roteador de páginas
│   │   └── presentation-layer.js     # Camada de apresentação
│   ├── css/
│   │   ├── main.css                  # Estilos globais
│   │   ├── canvas-rendering.css      # Estilos para Canvas
│   │   └── effects.css               # Efeitos visuais
│   ├── data/
│   │   ├── chapters.json             # Conteúdo dos 7 capítulos
│   │   └── fenomeno-phi-content.json # Conteúdo do Fenômeno Φ
│   └── templates/
│       ├── chapter-templates.json    # Templates Tracery
│       └── virtual-page-templates.json
├── public/
│   ├── index.html                    # Portal principal
│   └── book-viewer.html              # Visualizador do livro
├── docs/
│   ├── EVA_OSSO_HYBRID_SKELETON.md   # Especificação técnica
│   ├── ARCHITECTURE.md               # Documentação de arquitetura
│   └── DEPLOYMENT.md                 # Guia de implantação
├── .github/
│   └── workflows/
│       └── deploy.yml                # GitHub Actions para Cloudflare
├── .gitignore
├── package.json
├── wrangler.toml                     # Configuração Cloudflare
└── README.md                         # Este arquivo
```

## 🚀 Início Rápido

### Pré-requisitos
- Node.js 18+
- Git
- Conta no GitHub
- Conta no Cloudflare

### Instalação Local

```bash
# Clonar repositório
git clone https://github.com/wagnerpyter/eva-osso.git
cd eva-osso

# Instalar dependências
npm install

# Iniciar servidor de desenvolvimento
npm run dev

# Abrir http://localhost:3000
```

### Build para Produção

```bash
# Fazer build
npm run build

# Testar build localmente
npm run preview

# Deploy automático (via GitHub Actions)
git push origin main
```

## 🌐 Implantação no Cloudflare Pages

### Configuração Automática (GitHub Actions)

O projeto está configurado para deploy automático via GitHub Actions. Quando você faz push para `main`, o workflow automático:

1. Faz build do projeto
2. Faz deploy no Cloudflare Pages
3. Atualiza o site em `wagnerpyter.ia.br`

### Configuração Manual

Se preferir configurar manualmente:

```bash
# Instalar Wrangler CLI
npm install -g @cloudflare/wrangler

# Fazer login
wrangler login

# Deploy
wrangler pages deploy public/
```

## 📖 Uso

### Abrir o Portal Principal

Acesse `https://wagnerpyter.ia.br` para ver o portal com menu superior.

### Navegar no Livro Mutável

O livro está disponível em `https://wagnerpyter.ia.br/book/` com navegação horizontal.

### Explorar Páginas Virtuais

- Capítulos base: `/book/page/0` até `/book/page/6`
- Páginas antes: `/book/page/-1`, `/book/page/-2`, etc.
- Páginas depois: `/book/page/7`, `/book/page/8`, etc.
- Páginas virtuais extremas: `/book/page/147`, `/book/page/1000`, etc.

### Controles

- **Setas (← →):** Navegar entre páginas
- **Teclado:** Números para ir direto a uma página
- **Menu:** Controlar BPM, estado de matéria, vazamento

## 🔧 Configuração

### Variáveis de Ambiente

Criar arquivo `.env.local`:

```
VITE_BPM_DEFAULT=120
VITE_MUTATION_RATE=0.1
VITE_LEAK_RATE=0.05
VITE_ENABLE_ANALYTICS=true
```

### Personalização

Editar `src/data/fenomeno-phi-content.json` para customizar conteúdo dos capítulos.

## 📚 Documentação

Veja a pasta `docs/` para documentação completa:

- **EVA_OSSO_HYBRID_SKELETON.md:** Especificação técnica completa
- **ARCHITECTURE.md:** Detalhes de arquitetura
- **DEPLOYMENT.md:** Guia passo a passo de implantação

## 🎨 Estética Visual

O projeto implementa uma estética **pós-internet** inspirada em:

- **Net.art:** Projetos experimentais de arte de internet
- **Glitch Aesthetics:** Corrupção controlada como feature
- **Kinetic Typography:** Tipografia dinâmica e animada
- **Procedural Generation:** Conteúdo gerado algoritmicamente

## 🧬 Módulos Principais

### eva.js
Orquestrador central que coordena todos os módulos.

### rhythm.js
Motor de ritmo adaptativo que influencia mutações e vazamentos.

### leak.js
Sistema de vazamento que move conteúdo entre capítulos.

### seeds.js
Sistema de sementes que gera fragmentos mutáveis.

### narrative-mutation.js
Motor de mutação que transforma texto em múltiplos níveis.

### book-engine.js
Motor do livro que gerencia capítulos e estados de matéria.

### page-generator.js
Gerador de páginas virtuais sob demanda.

### page-router.js
Roteador que gerencia navegação horizontal.

### presentation-layer.js
Camada de apresentação que renderiza em Canvas com efeitos visuais.

## 🔄 Estados de Matéria

Cada capítulo pode estar em um de 4 estados:

- **Sólido:** Texto estável, sem mutação
- **Líquido:** Mutação leve, legível
- **Gasoso:** Mutação intensa, parcialmente legível
- **Plasma:** Superposição de versões, altamente instável

## 💾 Persistência

O estado do livro é salvo em `localStorage`:

- Página atual
- Mutações realizadas
- Páginas virtuais geradas
- Histórico de navegação
- Sementes plantadas

Sincronização entre abas usando `BroadcastChannel`.

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:

1. Faça fork do projeto
2. Crie uma branch (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📝 Licença

Este projeto está sob licença MIT. Veja `LICENSE` para detalhes.

## 👤 Autor

**Wagner Pyter** - Criador do Fenômeno Φ e do EVA OSSO Framework

## 🙏 Agradecimentos

- Inspiração em net.art e arte pós-internet
- Conceitos de narrativa procedural de Tracery (GalaxyKate)
- Estética de glitch e corrupção controlada

## 📞 Contato

- Site: https://wagnerpyter.ia.br
- Email: wagner@wagnerpyter.ia.br
- GitHub: https://github.com/wagnerpyter

---

**Versão:** 1.0 Híbrida  
**Status:** Em Desenvolvimento  
**Última Atualização:** Janeiro 2026

> "O vazamento é a feature. O livro que muta a cada leitura. Bem-vindo ao EVA OSSO." 🌀✨
