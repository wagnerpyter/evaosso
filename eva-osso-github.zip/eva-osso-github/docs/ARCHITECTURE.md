# Arquitetura do 'Livro Mutável' EVA OSSO

Este documento detalha a arquitetura proposta para transformar o projeto "Fenômeno Φ" em um "Livro Mutável" utilizando o EVA OSSO Framework. A premissa central é que o livro não é um objeto estático, mas um organismo vivo que respira, vaza e se transforma, refletindo os conceitos da arte e literatura pós-internet.

## 1. Os 7 Níveis como Capítulos Mutáveis

Cada um dos 7 Níveis do "Fenômeno Φ" será tratado como um capítulo independente, mas interconectado. O conteúdo de cada capítulo será armazenado de forma modular, permitindo que seja manipulado dinamicamente pelo EVA OSSO.

### Estrutura de Conteúdo:

*   **Capítulos Modulares:** Cada nível (0 a 6) terá seu conteúdo textual principal (descrições, filosofias, códigos) armazenado em um formato que possa ser facilmente acessado e modificado via JavaScript (e.g., arrays de strings, objetos JSON).
*   **Metadados por Capítulo:** Cada capítulo terá metadados associados, como `estado` (sólido, líquido, gasoso, plasma), `ritmo` (BPM preferencial), e `taxa de vazamento`.

## 2. Motor de Mutação Narrativa (seeds.js aprimorado)

O módulo `seeds.js` será o coração da mutação narrativa. As "sementes" não serão apenas identificadores, mas fragmentos textuais com potencial de transformação.

### Mecanismos de Mutação:

*   **Sementes Textuais:** Uma semente será um pequeno trecho de texto (palavra, frase, parágrafo) extraído de um capítulo. Cada semente terá um `dna` (hash do texto original) e um `genoma` (parâmetros de mutação).
*   **Algoritmos de Mutação:**
    *   **Substituição Léxica:** Troca de sinônimos ou palavras relacionadas, com base em um dicionário interno ou API externa (se disponível).
    *   **Reordenação Sintática:** Pequenas alterações na ordem das palavras ou frases para criar novas interpretações.
    *   **Injeção/Remoção:** Adição ou remoção de palavras/frases de outros capítulos (vazamento).
    *   **Mutação de Glifos:** Alteração de caracteres individuais (e.g., `a` para `á`, `e` para `é`) para simular degradação ou ruído.
*   **Taxa de Mutação:** Controlada pelo `Eva.Seeds.mutationRate` e influenciada pelo `Eva.Rhythm.currentBPM`. Um BPM mais alto pode levar a mutações mais frequentes e caóticas.

## 3. Vazamento Inter-Capítulos (leak.js aprimorado)

O `leak.js` será responsável por mover e transformar o conteúdo entre os capítulos, simulando o "vazamento" de informações.

### Mecanismos de Vazamento:

*   **Vazamento de Sementes:** Sementes geradas em um capítulo podem ser "vazadas" para o `seeds-container` de outro capítulo ou até mesmo para o `localStorage` do navegador.
*   **Vazamento Direcional:** Definir regras para o fluxo de vazamento (e.g., do Capítulo 0 para o 1, do 6 para o 0, etc.).
*   **Estética do Vazamento:** O CSS de vazamento (`.eva-leaking`) será aplicado a elementos textuais que estão ativamente vazando, criando efeitos visuais de desintegração ou sobreposição.

## 4. Ritmo Narrativo (rhythm.js aprimorado)

O `rhythm.js` ditará a pulsação do livro, afetando a frequência e intensidade das mutações e vazamentos.

### Influência do Ritmo:

*   **BPM e Mutação:** O `currentBPM` influenciará diretamente a taxa de mutação em `seeds.js` e a frequência de vazamento em `leak.js`.
*   **Animações Rítmicas:** Elementos textuais e visuais do livro podem pulsar, tremer ou se mover em sincronia com o BPM, criando uma experiência imersiva.
*   **Ciclo Shiva:** O `cyclePhase` pode ser usado para orquestrar grandes transformações narrativas ou visuais em pontos específicos do ciclo.

## 5. Orquestrador Central (eva.js aprimorado)

O `eva.js` coordenará todos os módulos, fornecendo uma API unificada para o "Livro Mutável".

### Funções Adicionais:

*   **`Eva.Book.init()`:** Inicializa o livro, carrega o conteúdo dos capítulos e configura os ouvintes de eventos.
*   **`Eva.Book.readChapter(chapterId)`:** Exibe o conteúdo de um capítulo, aplicando mutações e vazamentos conforme as regras.
*   **`Eva.Book.mutateChapter(chapterId, options)`:** Força uma mutação em um capítulo específico.
*   **`Eva.Book.leakChapter(chapterId, destinationChapterId)`:** Inicia um vazamento de conteúdo entre capítulos.
*   **`Eva.Book.saveState()` / `Eva.Book.loadState()`:** Persiste e carrega o estado atual do livro (mutações, sementes) no `localStorage`.

## 6. Interface e Estética (index.html e CSS)

O `index.html` será a interface do livro, com CSS e JavaScript para renderizar a experiência mutável.

### Elementos Visuais:

*   **Visualização de Capítulos:** Cada `level-card` pode se tornar um "portal" para um capítulo, exibindo um resumo mutável.
*   **Efeitos de Vazamento:** Animações CSS (`@keyframes leak`) serão aplicadas a blocos de texto que estão vazando, criando um efeito visual de desintegração ou sobreposição.
*   **Sementes Visíveis:** As sementes plantadas (`.eva-seed-planted`) podem ser pequenos fragmentos de texto que aparecem e desaparecem, ou se transformam visualmente.
*   **Tipografia Dinâmica:** Uso de CSS para alterar `font-weight`, `font-size` ou `letter-spacing` de forma sutil para refletir o ritmo ou o estado de mutação.

## Próximos Passos

Com esta arquitetura definida, o próximo passo será a implementação detalhada dos módulos JavaScript e a integração com o `index.html` para dar vida ao "Livro Mutável" do Fenômeno Φ.
