# Guia de Implantação - EVA OSSO no Cloudflare Pages

Este guia detalha como implantar o EVA OSSO no Cloudflare Pages e conectá-lo ao seu domínio `wagnerpyter.ia.br`.

## Pré-requisitos

- Conta no GitHub
- Conta no Cloudflare
- Domínio `wagnerpyter.ia.br` configurado no Cloudflare
- Node.js 18+ instalado localmente

## Passo 1: Preparar o Repositório GitHub

### 1.1 Criar Repositório

```bash
# Criar novo repositório no GitHub chamado "eva-osso"
# (ou usar um existente)

# Clonar o repositório
git clone https://github.com/wagnerpyter/eva-osso.git
cd eva-osso
```

### 1.2 Fazer Push do Código

```bash
# Adicionar todos os arquivos
git add .

# Fazer commit
git commit -m "Initial commit: EVA OSSO Framework v1.0"

# Fazer push para main
git push origin main
```

## Passo 2: Configurar Cloudflare Pages

### 2.1 Conectar GitHub ao Cloudflare Pages

1. Acesse [Cloudflare Dashboard](https://dash.cloudflare.com)
2. Selecione sua conta
3. Vá para **Pages**
4. Clique em **Create a project**
5. Selecione **Connect to Git**
6. Autorize o GitHub e selecione o repositório `eva-osso`
7. Clique em **Begin setup**

### 2.2 Configurar Build

Na página de configuração:

- **Project name:** `eva-osso`
- **Production branch:** `main`
- **Framework preset:** `None` (ou `Vite`)
- **Build command:** `npm run build`
- **Build output directory:** `dist`

Clique em **Save and Deploy**

### 2.3 Adicionar Variáveis de Ambiente

1. Vá para **Settings** → **Environment variables**
2. Adicione as seguintes variáveis:

```
NODE_ENV = production
VITE_BPM_DEFAULT = 120
VITE_MUTATION_RATE = 0.1
VITE_LEAK_RATE = 0.05
VITE_ENABLE_ANALYTICS = true
```

## Passo 3: Conectar Domínio Customizado

### 3.1 Adicionar Domínio

1. No projeto Cloudflare Pages, vá para **Custom domains**
2. Clique em **Add custom domain**
3. Digite `wagnerpyter.ia.br`
4. Clique em **Continue**
5. Confirme que o domínio está configurado no Cloudflare

### 3.2 Configurar DNS (se necessário)

Se o domínio não estiver automaticamente configurado:

1. Vá para **DNS** no Cloudflare Dashboard
2. Adicione um registro CNAME:
   - **Name:** `wagnerpyter.ia.br`
   - **Content:** `eva-osso.pages.dev`
   - **TTL:** Auto
   - **Proxy status:** Proxied

## Passo 4: Configurar GitHub Actions

### 4.1 Adicionar Secrets

1. Vá para o repositório GitHub
2. **Settings** → **Secrets and variables** → **Actions**
3. Clique em **New repository secret**
4. Adicione os seguintes secrets:

```
CLOUDFLARE_API_TOKEN: <seu_token_api>
CLOUDFLARE_ACCOUNT_ID: <seu_account_id>
```

### 4.2 Obter Credenciais Cloudflare

Para obter o `CLOUDFLARE_API_TOKEN`:

1. Acesse [Cloudflare API Tokens](https://dash.cloudflare.com/profile/api-tokens)
2. Clique em **Create Token**
3. Use o template **Edit Cloudflare Workers**
4. Configure as permissões:
   - **Account Resources:** Include - All accounts
   - **Zone Resources:** Include - All zones
5. Copie o token e adicione como secret

Para obter o `CLOUDFLARE_ACCOUNT_ID`:

1. Vá para [Cloudflare Dashboard](https://dash.cloudflare.com)
2. Selecione sua conta
3. Vá para **Pages**
4. O Account ID está na URL: `https://dash.cloudflare.com/<ACCOUNT_ID>/pages`

## Passo 5: Testar Implantação

### 5.1 Fazer Push para Ativar Deploy

```bash
# Fazer uma mudança pequena
echo "# EVA OSSO v1.0" >> README.md

# Commit e push
git add .
git commit -m "Test deployment"
git push origin main
```

### 5.2 Monitorar Deploy

1. Vá para o repositório GitHub
2. Clique em **Actions**
3. Veja o workflow `Deploy EVA OSSO to Cloudflare Pages` em execução
4. Aguarde a conclusão (geralmente 2-3 minutos)

### 5.3 Verificar Site

Acesse `https://wagnerpyter.ia.br` para verificar se o site está online.

## Passo 6: Configurações Adicionais

### 6.1 Configurar Redirects

Criar arquivo `_redirects` na pasta `public/`:

```
# Redirecionar /book para /book-viewer.html
/book /book-viewer.html 200

# Redirecionar /page/* para /book-viewer.html
/page/* /book-viewer.html 200

# Redirecionar URLs antigas
/old-url /new-url 301
```

### 6.2 Configurar Headers Customizados

Criar arquivo `_headers` na pasta `public/`:

```
# Headers de segurança
/*
  X-Content-Type-Options: nosniff
  X-Frame-Options: SAMEORIGIN
  X-XSS-Protection: 1; mode=block
  Referrer-Policy: strict-origin-when-cross-origin

# Cache para assets estáticos
/assets/*
  Cache-Control: public, max-age=31536000, immutable

# Cache para HTML
/*.html
  Cache-Control: public, max-age=3600

# Cache para JSON
/data/*
  Cache-Control: public, max-age=86400
```

### 6.3 Configurar Analytics

1. No Cloudflare Dashboard, vá para **Analytics & Logs**
2. Ative **Web Analytics**
3. Copie o script de tracking
4. Adicione ao `public/index.html` e `public/book-viewer.html`

## Passo 7: Monitoramento e Manutenção

### 7.1 Verificar Logs

```bash
# Ver logs do Cloudflare Pages
# (via dashboard)
```

### 7.2 Atualizar Código

Para atualizar o site:

```bash
# Fazer mudanças no código
# ...

# Commit e push
git add .
git commit -m "Update: descrição da mudança"
git push origin main

# Deploy automático será acionado
```

### 7.3 Rollback

Se algo der errado:

```bash
# Reverter para commit anterior
git revert <commit_hash>
git push origin main

# Ou resetar para um commit específico
git reset --hard <commit_hash>
git push origin main --force
```

## Troubleshooting

### Build falha

**Problema:** Build falha com erro de dependências

**Solução:**
```bash
# Limpar cache
rm -rf node_modules package-lock.json

# Reinstalar
npm install

# Fazer push
git add .
git commit -m "Fix: reinstall dependencies"
git push origin main
```

### Site não carrega

**Problema:** Site retorna erro 404 ou 500

**Solução:**
1. Verificar logs no Cloudflare Dashboard
2. Verificar se o build output directory está correto (`dist`)
3. Verificar se o arquivo `_redirects` está configurado

### Domínio não funciona

**Problema:** Domínio não resolve para o site

**Solução:**
1. Verificar DNS no Cloudflare
2. Aguardar propagação DNS (até 48 horas)
3. Limpar cache do navegador
4. Testar com `curl https://wagnerpyter.ia.br`

## Próximos Passos

1. **Configurar Email:** Adicionar email customizado via Cloudflare
2. **Configurar SSL:** Verificar certificado SSL (automático no Cloudflare)
3. **Otimizar Performance:** Usar Cloudflare Workers para cache avançado
4. **Monitorar Uptime:** Configurar alertas de uptime no Cloudflare
5. **Análise de Tráfego:** Usar Google Analytics ou Cloudflare Analytics

## Recursos Úteis

- [Cloudflare Pages Documentation](https://developers.cloudflare.com/pages/)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Vite Documentation](https://vitejs.dev/)
- [Cloudflare DNS Documentation](https://developers.cloudflare.com/dns/)

---

**Versão:** 1.0  
**Última Atualização:** Janeiro 2026  
**Autor:** Wagner Pyter

Se encontrar problemas, abra uma issue no [GitHub](https://github.com/wagnerpyter/eva-osso/issues).
