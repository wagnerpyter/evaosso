# EVA OSSO Framework v1.0 - Versão Híbrida
## Estrutura Esqueleto do Livro Mutável Pós-Internet

---

## 1. Visão Geral da Arquitetura

O **EVA OSSO** é um framework para criar um **Livro Mutável** que existe em um espaço pós-internet, onde a narrativa é gerada proceduralmente, o conteúdo vaza entre capítulos, e o leitor pode navegar infinitamente através de páginas que não existem fisicamente no servidor.

### Princípios Fundamentais

*   **Mutação Contínua:** O texto não é estático; ele se transforma a cada leitura baseado em ritmo, estado e interação.
*   **Vazamento Narrativo:** Fragmentos de um capítulo "vazam" para outro, criando uma rede interconectada de conteúdo.
*   **Navegação Horizontal:** Em vez de scroll vertical, o leitor navega horizontalmente através de capítulos e páginas virtuais.
*   **Páginas Virtuais Infinitas:** Páginas que não existem no servidor são geradas sob demanda (ex: -1, 7, 147).
*   **Persistência Local:** Cada página gerada é salva no `localStorage`, permitindo que o livro "lembre" de suas mutações.
*   **Estética Pós-Internet:** A interface é arte em si mesma, refletindo conceitos de net.art, glitch e corrupção controlada.

---

## 2. Arquitetura de Camadas

```
┌─────────────────────────────────────────────────────────────┐
│                    CAMADA DE APRESENTAÇÃO                   │
│  (Canvas 2D + SVG + Kinetic Typography + Interatividade)   │
├─────────────────────────────────────────────────────────────┤
│                    CAMADA DE NAVEGAÇÃO                      │
│  (Horizontal Scroll + Page Router + Virtual Page Generator) │
├─────────────────────────────────────────────────────────────┤
│                    CAMADA DE NARRATIVA                      │
│  (Book Engine + Narrative Mutation + Tracery Templates)     │
├─────────────────────────────────────────────────────────────┤
│                    CAMADA DE RITMO & VAZAMENTO              │
│  (Rhythm Engine + Leak Network + Seed System)               │
├─────────────────────────────────────────────────────────────┤
│                    CAMADA DE PERSISTÊNCIA                   │
│  (localStorage + IndexedDB + State Management)              │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. Módulos Principais

### 3.1 **eva.js** - Orquestrador Central
Coordena todos os módulos e fornece uma API unificada.

```javascript
Eva = {
  // Inicialização
  init(config),
  
  // Ritmo
  Rhythm: {
    currentBPM,
    cyclePhase,
    start(),
    stop(),
    setBPM(bpm)
  },
  
  // Vazamento
  Leak: {
    leakBetweenChapters(source, dest),
    getLeakNetwork(),
    visualizeLeaks()
  },
  
  // Sementes
  Seeds: {
    generateSeed(),
    plantSeed(seed),
    harvestSeeds(),
    mutationRate
  },
  
  // Livro
  Book: {
    readChapter(id),
    readVirtualPage(pageNumber),
    navigateTo(pageNumber),
    getPageContent(pageNumber),
    saveState(),
    loadState()
  },
  
  // Narrativa
  Narrative: {
    mutateText(text, options),
    generateVirtualPageContent(pageNumber),
    getChapterMetadata(id)
  }
}
```

### 3.2 **rhythm.js** - Motor de Ritmo
Define o BPM adaptativo que influencia mutações e vazamentos.

**Responsabilidades:**
- Calcular BPM baseado na hora do dia, velocidade da conexão, ou entrada do usuário
- Gerenciar ciclos Shiva (criação, manutenção, destruição)
- Sincronizar animações visuais com o ritmo
- Disparar eventos de "batida" para outros módulos

**Saída:**
```javascript
{
  currentBPM: 120,
  cyclePhase: 0.5, // 0-1
  isRunning: true,
  events: ['beat', 'cycle-phase-change']
}
```

### 3.3 **leak.js** - Sistema de Vazamento
Gerencia o fluxo de conteúdo entre capítulos e destinos.

**Responsabilidades:**
- Extrair fragmentos de capítulos
- Injetar fragmentos em outros capítulos
- Gerenciar rede de vazamento (quem vaza para quem)
- Aplicar efeitos visuais de vazamento

**Rede de Vazamento Padrão:**
```
0 → 1 → 2 → 3 → 4 → 5 → 6 → 0 (circular)
↓       ↓       ↓       ↓       ↓
-1      7       147     ...     (páginas virtuais)
```

### 3.4 **seeds.js** - Sistema de Sementes
Gerencia fragmentos de código/texto que crescem e se mutam.

**Responsabilidades:**
- Gerar sementes com DNA único
- Aplicar mutações genéticas às sementes
- Plantar sementes no livro
- Colher sementes para persistência

**Estrutura de Semente:**
```javascript
{
  id: "SEED_UUID",
  dna: "hash_do_original",
  genoma: {
    mutationRate: 0.1,
    lifespan: 5000,
    generation: 1
  },
  content: "fragmento de texto",
  plantedAt: timestamp,
  location: { chapter: 0, position: 100 }
}
```

### 3.5 **narrative-mutation.js** - Motor de Mutação Narrativa
Aplica transformações ao texto em múltiplos níveis.

**Mecanismos de Mutação:**
- Léxica (substituição de sinônimos)
- Sintática (reordenação de palavras)
- Glífica (alteração de caracteres)
- Injeção de fragmentos
- Remoção de fragmentos

**Entrada/Saída:**
```javascript
// Entrada
text = "O livro mutável da IA"
options = { lexicalRate: 0.1, bpm: 120 }

// Saída
"O organismo vivo da inteligência artificial"
```

### 3.6 **book-engine.js** - Motor do Livro Mutável
Orquestra capítulos, estados e leitura contínua.

**Responsabilidades:**
- Gerenciar 7 capítulos base (0-6)
- Gerar páginas virtuais sob demanda
- Aplicar estados de matéria (sólido, líquido, gasoso, plasma)
- Sincronizar leitura com ritmo

**Estados de Matéria:**
- **Sólido:** Texto estável, sem mutação
- **Líquido:** Mutação leve, legível
- **Gasoso:** Mutação intensa, parcialmente legível
- **Plasma:** Superposição de versões, altamente instável

### 3.7 **page-generator.js** - Gerador de Páginas Virtuais
Cria páginas que não existem fisicamente.

**Algoritmo:**
```
Para página N:
  1. Determinar "distância" de N em relação aos capítulos 0-6
  2. Calcular blend de capítulos base (ex: -1 = 100% cap 0 + vazamento)
  3. Aplicar mutações baseadas em N (quanto maior N, mais mutado)
  4. Gerar seed único para a página
  5. Salvar no localStorage com hash de N
  6. Retornar conteúdo renderizado
```

**Exemplo:**
```
Página -1: 100% Cap 0 + 20% vazamento de Cap 6
Página 7: 60% Cap 0 + 40% Cap 1 + mutação intensa
Página 147: Blend complexo de todos os capítulos + mutação extrema
```

### 3.8 **page-router.js** - Roteador de Páginas
Gerencia navegação horizontal e roteamento.

**Responsabilidades:**
- Interceptar URLs como `/page/147`
- Verificar se página existe em cache (localStorage)
- Gerar página se não existir
- Atualizar URL sem recarregar
- Gerenciar histórico de navegação

### 3.9 **presentation-layer.js** - Camada de Apresentação
Renderiza conteúdo em Canvas/SVG com efeitos visuais.

**Responsabilidades:**
- Renderizar texto em Canvas 2D com tipografia dinâmica
- Aplicar efeitos de vazamento (partículas, dissolução)
- Sincronizar animações com BPM
- Gerenciar interatividade (hover, click)
- Renderizar estado plasma (superposição)

**Efeitos Visuais:**
- Tipografia Cinética: Letras se movem em sincronia com BPM
- Vazamento: Texto se desintegra em partículas
- Glitch: Aberração cromática, scan lines, deslocamento de camadas
- Superposição: Múltiplas versões do texto com transparência

---

## 4. Fluxo de Dados

### 4.1 Leitura de um Capítulo Base (0-6)

```
Usuário navega para /page/3
    ↓
PageRouter intercepta URL
    ↓
Verifica localStorage para página 3
    ↓
Se não existe, BookEngine.readChapter(3)
    ↓
NarrativeMutation aplica transformações baseadas em BPM
    ↓
PresentationLayer renderiza em Canvas com efeitos
    ↓
Página salva em localStorage
    ↓
Exibida ao usuário
```

### 4.2 Navegação para Página Virtual

```
Usuário navega para /page/147
    ↓
PageRouter intercepta URL
    ↓
Verifica localStorage para página 147
    ↓
Se não existe, PageGenerator.generateVirtualPage(147)
    ↓
Algoritmo calcula blend de capítulos base
    ↓
NarrativeMutation aplica mutação extrema (baseada em 147)
    ↓
PresentationLayer renderiza com efeitos intensos
    ↓
Página salva em localStorage com hash
    ↓
Exibida ao usuário
```

### 4.3 Vazamento Contínuo

```
Eva.Rhythm emite evento 'beat'
    ↓
Eva.Leak.leakBetweenChapters() é acionado
    ↓
Extrai fragmento de capítulo fonte
    ↓
Injeta em capítulo destino
    ↓
NarrativeMutation aplica mutação ao fragmento
    ↓
PresentationLayer anima vazamento (partículas fluindo)
    ↓
Novo estado salvo em localStorage
```

---

## 5. Estrutura de Arquivos

```
eva-osso-fenomeno/
├── index.html                    # Portal principal com menu
├── book-viewer.html              # Iframe que exibe o livro
├── eva.js                        # Orquestrador central
├── rhythm.js                     # Motor de ritmo
├── leak.js                       # Sistema de vazamento
├── seeds.js                      # Sistema de sementes
├── narrative-mutation.js         # Motor de mutação narrativa
├── book-engine.js                # Motor do livro mutável
├── page-generator.js             # Gerador de páginas virtuais
├── page-router.js                # Roteador de páginas
├── presentation-layer.js         # Camada de apresentação
├── styles/
│   ├── main.css                  # Estilos globais
│   ├── canvas-rendering.css      # Estilos para Canvas
│   └── effects.css               # Efeitos visuais (vazamento, glitch)
├── templates/
│   ├── chapter-templates.json    # Templates Tracery para capítulos
│   └── virtual-page-templates.json # Templates para páginas virtuais
├── data/
│   ├── chapters.json             # Conteúdo dos 7 capítulos base
│   └── fenomeno-phi-content.json # Conteúdo do Fenômeno Φ
└── docs/
    ├── EVA_OSSO_HYBRID_SKELETON.md (este arquivo)
    ├── visual_aesthetics_options.md
    ├── mutable_book_architecture.md
    └── README.md
```

---

## 6. Fluxo de Inicialização

```javascript
// 1. Carregar módulos
import Eva from './eva.js';
import Rhythm from './rhythm.js';
import Leak from './leak.js';
import Seeds from './seeds.js';
import BookEngine from './book-engine.js';
import NarrativeMutation from './narrative-mutation.js';
import PageGenerator from './page-generator.js';
import PageRouter from './page-router.js';
import PresentationLayer from './presentation-layer.js';

// 2. Inicializar EVA
Eva.init({
  bpm: 120,
  chapters: chaptersData,
  templates: traceryTemplates,
  canvas: document.getElementById('book-canvas')
});

// 3. Iniciar ritmo
Eva.Rhythm.start();

// 4. Iniciar roteador
Eva.PageRouter.init();

// 5. Carregar estado anterior (se existir)
Eva.Book.loadState();

// 6. Pronto para navegação
console.log('📖 EVA OSSO inicializado');
```

---

## 7. Interação do Usuário

### 7.1 Navegação Horizontal
```
[Página -2] [Página -1] [Cap 0] [Cap 1] [Cap 2] ... [Cap 6] [Página 7] [Página 8]
                                    ↑
                            (Posição atual)
```

O usuário pode:
- Clicar em setas para navegar
- Usar teclado (← →)
- Scroll horizontal (se suportado)
- Digitar número de página

### 7.2 Chat Interativo
O chat pode sugerir páginas virtuais:
- "Explore a página 42"
- "Vá para o capítulo -5"
- "Visite a página 1000 para uma experiência extrema"

### 7.3 Controles de Ritmo
- Botão para aumentar/diminuir BPM
- Botão para mudar estado de matéria
- Botão para iniciar/parar vazamento

---

## 8. Persistência e Estado

### 8.1 localStorage
```javascript
{
  'eva-book-state': {
    timestamp: Date.now(),
    currentPage: 3,
    bookState: { totalMutations, totalLeaks, ... },
    chapters: { ... },
    virtualPages: { 147: { content, mutations, ... }, ... }
  },
  'eva-page-cache': {
    3: { content, hash, timestamp },
    147: { content, hash, timestamp },
    ...
  },
  'eva-seeds': [
    { id, dna, genoma, content, plantedAt, location },
    ...
  ]
}
```

### 8.2 Sincronização Entre Abas
Usar `BroadcastChannel` para sincronizar estado entre abas do navegador.

---

## 9. Métricas e Analytics

O EVA OSSO rastreia:
- Total de mutações realizadas
- Total de vazamentos
- Páginas visitadas
- Tempo de leitura por página
- Sementes geradas e colhidas
- Caminho de navegação (para análise de padrões)

---

## 10. Extensibilidade

O framework é projetado para ser extensível:

### 10.1 Adicionar Novos Mecanismos de Mutação
```javascript
NarrativeMutation.registerMutationStrategy('custom', (text, options) => {
  // Implementar lógica customizada
  return mutatedText;
});
```

### 10.2 Adicionar Novos Efeitos Visuais
```javascript
PresentationLayer.registerEffect('custom-effect', (canvas, text, options) => {
  // Implementar efeito visual customizado
});
```

### 10.3 Integrar APIs Externas
```javascript
Eva.Narrative.integrateExternalAPI('openai', {
  endpoint: 'https://api.openai.com/v1/completions',
  model: 'gpt-4',
  useForEnhancedMutation: true
});
```

---

## 11. Roadmap de Implementação

### Fase 1: Núcleo (Semana 1-2)
- [ ] Implementar `eva.js`, `rhythm.js`, `leak.js`, `seeds.js`
- [ ] Criar `narrative-mutation.js` com mecanismos básicos
- [ ] Implementar `book-engine.js` para 7 capítulos base

### Fase 2: Navegação e Geração (Semana 3-4)
- [ ] Implementar `page-generator.js` para páginas virtuais
- [ ] Criar `page-router.js` para roteamento
- [ ] Integrar Tracery para templates

### Fase 3: Apresentação (Semana 5-6)
- [ ] Implementar `presentation-layer.js` com Canvas 2D
- [ ] Adicionar efeitos visuais (vazamento, glitch, superposição)
- [ ] Sincronizar com ritmo

### Fase 4: Interface e Integração (Semana 7-8)
- [ ] Criar `index.html` com menu superior
- [ ] Criar `book-viewer.html` com navegação horizontal
- [ ] Integrar chat interativo
- [ ] Testes e otimizações

---

## 12. Conclusão

O EVA OSSO é um framework híbrido que combina:
- **Procedural Generation** (páginas virtuais infinitas)
- **Narrative Mutation** (transformação contínua de texto)
- **Rhythm-Driven Design** (BPM adaptativo)
- **Network Aesthetics** (vazamento entre capítulos)
- **Post-Internet Aesthetics** (glitch, corrupção, net.art)

Resultado: Um **Livro Mutável** que é simultaneamente um organismo vivo, uma obra de arte, e uma experiência interativa única para cada leitor.

---

**Versão:** 1.0 Híbrida  
**Data:** Janeiro 2026  
**Autor:** Manus AI + Wagner Pyter  
**Status:** Pronto para Implementação
