/**
 * EVA OSSO Framework v1.0 - book-engine.js
 * "Motor do Livro Mutável"
 * 
 * Orquestrador do livro mutável com capítulos dinâmicos
 */

class BookEngine {
  constructor() {
    this.chapters = {};
    this.currentChapter = null;
    this.narrativeMutation = new NarrativeMutation();
    this.leakNetwork = {};
    this.bookState = {
      totalMutations: 0,
      totalLeaks: 0,
      chaptersRead: 0,
      timeStarted: Date.now()
    };
  }

  /**
   * Inicializa o livro com capítulos
   */
  initializeBook(chaptersData) {
    Object.entries(chaptersData).forEach(([id, data]) => {
      this.chapters[id] = {
        id: id,
        title: data.title,
        originalContent: data.content,
        currentContent: data.content,
        mutationCount: 0,
        leakCount: 0,
        state: 'solid', // solid, liquid, gaseous, plasma
        bpm: 120,
        lastMutated: null,
        seeds: []
      };
    });
    
    console.log(`📖 Livro inicializado com ${Object.keys(this.chapters).length} capítulos`);
  }

  /**
   * Lê um capítulo, aplicando mutações conforme o ritmo
   */
  readChapter(chapterId) {
    if (!this.chapters[chapterId]) {
      console.warn(`⚠️ Capítulo ${chapterId} não encontrado`);
      return null;
    }

    const chapter = this.chapters[chapterId];
    this.currentChapter = chapterId;

    // Aplica mutação adaptativa baseada no BPM
    const bpm = window.Eva?.Rhythm?.currentBPM || 120;
    chapter.bpm = bpm;

    // Mutação baseada no estado do capítulo
    if (chapter.state === 'liquid') {
      chapter.currentContent = this.narrativeMutation.mutateAdaptive(
        chapter.originalContent,
        bpm
      );
    } else if (chapter.state === 'gaseous') {
      chapter.currentContent = this.narrativeMutation.mutateComprehensively(
        chapter.originalContent,
        {
          lexicalRate: 0.2,
          syntacticRate: 0.15,
          glyphRate: 0.05,
          removalRate: 0.1
        }
      );
    } else if (chapter.state === 'plasma') {
      // Estado plasma: múltiplas versões simultâneas
      chapter.currentContent = this.generatePlasmaVersion(chapter.originalContent);
    }

    chapter.mutationCount++;
    chapter.lastMutated = Date.now();
    this.bookState.totalMutations++;
    this.bookState.chaptersRead++;

    console.log(`📖 Lendo capítulo ${chapterId} [${chapter.state}] - Mutações: ${chapter.mutationCount}`);
    
    return chapter;
  }

  /**
   * Gera versão plasma (superposição de textos)
   */
  generatePlasmaVersion(content) {
    const version1 = this.narrativeMutation.mutateLexically(content, 0.15);
    const version2 = this.narrativeMutation.mutateSyntactically(content, 0.1);
    
    // Retorna ambas as versões em superposição (via HTML)
    return `<div class="plasma-superposition">
      <span class="plasma-v1">${version1}</span>
      <span class="plasma-v2">${version2}</span>
    </div>`;
  }

  /**
   * Define o estado de um capítulo
   */
  setChapterState(chapterId, state) {
    if (this.chapters[chapterId]) {
      this.chapters[chapterId].state = state;
      console.log(`🔄 Capítulo ${chapterId} mudou para estado: ${state}`);
    }
  }

  /**
   * Inicia vazamento entre capítulos
   */
  leakBetweenChapters(sourceId, destinationId, fragmentSize = 50) {
    if (!this.chapters[sourceId] || !this.chapters[destinationId]) {
      console.warn(`⚠️ Capítulos não encontrados`);
      return;
    }

    const source = this.chapters[sourceId];
    const destination = this.chapters[destinationId];

    // Extrai um fragmento do capítulo fonte
    const words = source.currentContent.split(/\s+/);
    const startIdx = Math.floor(Math.random() * Math.max(0, words.length - fragmentSize));
    const fragment = words.slice(startIdx, startIdx + fragmentSize).join(' ');

    // Injeta no capítulo destino
    destination.currentContent = this.narrativeMutation.injectFragment(
      destination.currentContent,
      fragment,
      1.0 // Garante injeção
    );

    source.leakCount++;
    destination.leakCount++;
    this.bookState.totalLeaks++;

    console.log(`💧 Vazamento: ${sourceId} → ${destinationId}`);
  }

  /**
   * Simula leitura contínua com mutações periódicas
   */
  startContinuousReading(chapterId, interval = 5000) {
    const chapter = this.chapters[chapterId];
    if (!chapter) return;

    const readingLoop = setInterval(() => {
      if (window.Eva?.Rhythm?.isRunning) {
        // Muta o capítulo a cada intervalo
        chapter.currentContent = this.narrativeMutation.mutateAdaptive(
          chapter.currentContent,
          window.Eva.Rhythm.currentBPM
        );

        // Ocasionalmente causa vazamento para outro capítulo
        if (Math.random() < 0.2) {
          const otherChapterId = Object.keys(this.chapters)[
            Math.floor(Math.random() * Object.keys(this.chapters).length)
          ];
          if (otherChapterId !== chapterId) {
            this.leakBetweenChapters(chapterId, otherChapterId);
          }
        }

        // Dispara evento de atualização
        const event = new CustomEvent('book-chapter-updated', {
          detail: { chapterId, content: chapter.currentContent }
        });
        document.dispatchEvent(event);
      }
    }, interval);

    return readingLoop;
  }

  /**
   * Salva o estado do livro
   */
  saveState() {
    const state = {
      timestamp: Date.now(),
      bookState: this.bookState,
      chapters: Object.entries(this.chapters).reduce((acc, [id, chapter]) => {
        acc[id] = {
          currentContent: chapter.currentContent,
          mutationCount: chapter.mutationCount,
          state: chapter.state
        };
        return acc;
      }, {})
    };

    localStorage.setItem('eva-book-state', JSON.stringify(state));
    console.log('💾 Estado do livro salvo');
    return state;
  }

  /**
   * Carrega o estado do livro
   */
  loadState() {
    const saved = localStorage.getItem('eva-book-state');
    if (saved) {
      try {
        const state = JSON.parse(saved);
        Object.entries(state.chapters).forEach(([id, data]) => {
          if (this.chapters[id]) {
            this.chapters[id].currentContent = data.currentContent;
            this.chapters[id].mutationCount = data.mutationCount;
            this.chapters[id].state = data.state;
          }
        });
        this.bookState = state.bookState;
        console.log('📖 Estado do livro carregado');
        return state;
      } catch (e) {
        console.warn('⚠️ Erro ao carregar estado:', e);
      }
    }
    return null;
  }

  /**
   * Obtém estatísticas do livro
   */
  getStats() {
    return {
      ...this.bookState,
      chapters: Object.entries(this.chapters).reduce((acc, [id, chapter]) => {
        acc[id] = {
          title: chapter.title,
          state: chapter.state,
          mutationCount: chapter.mutationCount,
          leakCount: chapter.leakCount
        };
        return acc;
      }, {})
    };
  }

  /**
   * Exibe estatísticas no console
   */
  showStats() {
    const stats = this.getStats();
    console.log('%c📖 ESTATÍSTICAS DO LIVRO MUTÁVEL', 'font-size: 16px; color: #0af; font-weight: bold;');
    console.table(stats);
  }

  /**
   * Reinicia o livro
   */
  reset() {
    Object.values(this.chapters).forEach(chapter => {
      chapter.currentContent = chapter.originalContent;
      chapter.mutationCount = 0;
      chapter.leakCount = 0;
      chapter.state = 'solid';
    });
    this.bookState = {
      totalMutations: 0,
      totalLeaks: 0,
      chaptersRead: 0,
      timeStarted: Date.now()
    };
    console.log('🔄 Livro reiniciado');
  }
}

// Exportar para uso global
if (typeof window !== 'undefined') {
  window.BookEngine = BookEngine;
}
