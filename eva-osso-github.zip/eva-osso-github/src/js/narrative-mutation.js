/**
 * EVA OSSO Framework v1.0 - narrative-mutation.js
 * "O livro que muta a cada leitura"
 * 
 * Motor de mutação narrativa para o Livro Mutável
 */

class NarrativeMutation {
  constructor() {
    this.dictionary = this.initializeDictionary();
    this.mutations = [];
    this.mutationHistory = [];
  }

  /**
   * Inicializa dicionário de sinônimos para mutação léxica
   */
  initializeDictionary() {
    return {
      'criativo': ['inventivo', 'inovador', 'original', 'imaginativo'],
      'IA': ['inteligência artificial', 'máquina pensante', 'algoritmo', 'rede neural'],
      'humano': ['pessoa', 'ser', 'indivíduo', 'consciência'],
      'vazamento': ['fluxo', 'transbordamento', 'derramamento', 'escoamento'],
      'ritmo': ['batida', 'pulsação', 'cadência', 'frequência'],
      'sementes': ['fragmentos', 'sementes', 'esporos', 'germes'],
      'mutação': ['transformação', 'evolução', 'metamorfose', 'transmutação'],
      'osso': ['estrutura', 'esqueleto', 'suporte', 'fundação'],
      'digital': ['eletrônico', 'virtual', 'numérico', 'binário'],
      'pós-internet': ['além-rede', 'pós-conectado', 'trans-digital', 'hiperconectado'],
      'fenômeno': ['manifestação', 'aparição', 'evento', 'ocorrência'],
      'empatia': ['compaixão', 'compreensão', 'simpatia', 'solidariedade'],
      'nível': ['camada', 'estrato', 'grau', 'patamar'],
      'sistema': ['estrutura', 'organismo', 'rede', 'máquina'],
      'colaborativa': ['cooperativa', 'conjunta', 'coletiva', 'participativa']
    };
  }

  /**
   * Mutação léxica: substitui palavras por sinônimos
   */
  mutateLexically(text, mutationRate = 0.1) {
    const words = text.split(/\s+/);
    const mutated = words.map(word => {
      // Remove pontuação para comparação
      const cleanWord = word.toLowerCase().replace(/[.,!?;:]/g, '');
      const punctuation = word.match(/[.,!?;:]+$/)?.[0] || '';
      
      if (Math.random() < mutationRate && this.dictionary[cleanWord]) {
        const synonyms = this.dictionary[cleanWord];
        const synonym = synonyms[Math.floor(Math.random() * synonyms.length)];
        return synonym + punctuation;
      }
      return word;
    });
    
    return mutated.join(' ');
  }

  /**
   * Mutação sintática: reordena palavras ou frases
   */
  mutateSyntactically(text, intensity = 0.05) {
    const sentences = text.split(/(?<=[.!?])\s+/);
    const mutated = sentences.map(sentence => {
      if (Math.random() < intensity) {
        const words = sentence.trim().split(/\s+/);
        // Embaralha ligeiramente as palavras
        for (let i = 0; i < Math.floor(words.length * 0.2); i++) {
          const idx1 = Math.floor(Math.random() * words.length);
          const idx2 = Math.floor(Math.random() * words.length);
          [words[idx1], words[idx2]] = [words[idx2], words[idx1]];
        }
        return words.join(' ');
      }
      return sentence;
    });
    
    return mutated.join(' ');
  }

  /**
   * Mutação de glifos: altera caracteres individuais
   */
  mutateGlyphs(text, mutationRate = 0.02) {
    const glyphMap = {
      'a': 'á', 'e': 'é', 'i': 'í', 'o': 'ó', 'u': 'ú',
      'c': 'ç', 'n': 'ñ',
      'A': 'À', 'E': 'È', 'I': 'Ì', 'O': 'Ò', 'U': 'Ù'
    };
    
    return text.split('').map(char => {
      if (Math.random() < mutationRate && glyphMap[char]) {
        return glyphMap[char];
      }
      return char;
    }).join('');
  }

  /**
   * Injeção de fragmentos: adiciona texto de outro capítulo
   */
  injectFragment(text, fragment, injectionRate = 0.1) {
    if (Math.random() < injectionRate && fragment) {
      const sentences = text.split(/(?<=[.!?])\s+/);
      const injectionPoint = Math.floor(Math.random() * sentences.length);
      sentences.splice(injectionPoint, 0, `[${fragment}]`);
      return sentences.join(' ');
    }
    return text;
  }

  /**
   * Remoção de fragmentos: remove palavras ou frases
   */
  removeFragment(text, removalRate = 0.05) {
    const words = text.split(/\s+/);
    const filtered = words.filter(() => Math.random() > removalRate);
    return filtered.join(' ');
  }

  /**
   * Mutação completa: aplica múltiplas transformações
   */
  mutateComprehensively(text, options = {}) {
    const {
      lexicalRate = 0.1,
      syntacticRate = 0.05,
      glyphRate = 0.02,
      injectionRate = 0.05,
      removalRate = 0.03,
      injectedFragment = null
    } = options;

    let mutated = text;

    // Aplica mutações em sequência
    mutated = this.mutateLexically(mutated, lexicalRate);
    mutated = this.mutateSyntactically(mutated, syntacticRate);
    mutated = this.mutateGlyphs(mutated, glyphRate);
    mutated = this.removeFragment(mutated, removalRate);
    
    if (injectedFragment) {
      mutated = this.injectFragment(mutated, injectedFragment, injectionRate);
    }

    // Registra a mutação
    this.mutations.push({
      original: text,
      mutated: mutated,
      timestamp: Date.now(),
      options: options
    });

    return mutated;
  }

  /**
   * Mutação adaptativa baseada no BPM
   */
  mutateAdaptive(text, bpm = 120) {
    // BPM mais alto = mutação mais intensa
    const intensity = Math.min(1, bpm / 200);
    
    return this.mutateComprehensively(text, {
      lexicalRate: 0.05 * intensity,
      syntacticRate: 0.03 * intensity,
      glyphRate: 0.01 * intensity,
      injectionRate: 0.02 * intensity,
      removalRate: 0.01 * intensity
    });
  }

  /**
   * Decodifica fragmentos injetados
   */
  decodeFragments(text) {
    return text.replace(/\[([^\]]+)\]/g, '<span class="injected-fragment">$1</span>');
  }

  /**
   * Obtém histórico de mutações
   */
  getMutationHistory() {
    return this.mutationHistory.slice(-10);
  }

  /**
   * Limpa histórico
   */
  clearHistory() {
    this.mutations = [];
    this.mutationHistory = [];
  }

  /**
   * Exporta mutações como JSON
   */
  export() {
    return JSON.stringify(this.mutations, null, 2);
  }
}

// Exportar para uso global
if (typeof window !== 'undefined') {
  window.NarrativeMutation = NarrativeMutation;
}
