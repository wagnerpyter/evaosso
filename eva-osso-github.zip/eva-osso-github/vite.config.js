import { defineConfig } from 'vite'

export default defineConfig({
  root: 'public',
  build: {
    outDir: '../dist',
    emptyOutDir: true,
    minify: 'terser',
    sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks: {
          'eva-core': ['src/js/eva.js', 'src/js/rhythm.js', 'src/js/leak.js', 'src/js/seeds.js'],
          'eva-narrative': ['src/js/narrative-mutation.js', 'src/js/book-engine.js'],
          'eva-navigation': ['src/js/page-generator.js', 'src/js/page-router.js'],
          'eva-presentation': ['src/js/presentation-layer.js']
        }
      }
    }
  },
  server: {
    port: 3000,
    open: true,
    cors: true,
    historyApiFallback: true
  },
  preview: {
    port: 4173,
    open: true
  },
  define: {
    __DEV__: JSON.stringify(process.env.NODE_ENV === 'development'),
    __VERSION__: JSON.stringify('1.0.0')
  }
})
